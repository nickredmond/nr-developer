--- SYSTEM REQUIREMENTS ---

* Windows XP or higher
* DirectX 9 or higher (available at https://www.microsoft.com/en-us/download/details.aspx?id=35)

--- TO RUN ---

1. Extract CorkyDorkz.zip
2. Navigate to extracted folder
3. Double-click CorkyDorkz.exe

--- DEMOGRAPHIC ---

This application is targeted to any Windows users who love a silly platform game. It’s 
also targeted to any user who would like to see me as the final boss of a PC game.  

--- CONTROLS ---

IN-GAME:

* Left/Right arrow keys - move left and right
* Up arrow key - jump
* Space - shoot laser

--- --- --- --- --- ---

KNOWN BUGS:

* Collecting all 19 keys should unlock “survival” mode, but it has not worked since I 
  was in college...
* Sometimes, the game will crash after getting a “game over” for reasons yet to be 
  determined.
* “Boss” music does not stop playing once the user wins the game.

--- CREDITS ---

Music: Ashtinh Le